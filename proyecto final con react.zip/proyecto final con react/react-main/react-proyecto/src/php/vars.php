<?php

$nombre_fichero = __DIR__."/tiendaequipos.sqlite3";

?>